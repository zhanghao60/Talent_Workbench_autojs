"""
这个是工具类，用于处理http请求以及mq消息等
"""
import json
import os

# 工具类
class Utils:
    def process_http_message(self, message):
        """
        从HTTP消息中提取指定字段
        
        Args:
            message: HTTP请求中的JSON数据
            
        Returns:
            dict: 包含提取字段的http_data字典
        """
        http_data = {}
        
        # 提取指定字段
        if 'data' in message:
            data = message['data']
            http_data['token'] = data.get('token', '')
            http_data['username'] = data.get('username', '')
            http_data['userId'] = data.get('userId', '')
            http_data['userCode'] = data.get('userCode', '')
            http_data['最低任务佣金'] = data.get('最低任务佣金', '')
            http_data['关联ID'] = data.get('关联ID', {})
        
        return http_data

    def process_mq_message(self, userid):
        """
        根据userid从task_json文件夹中查找指定的userid文件夹，
        再获取最新的json文件，提取指定的字段并返回
        """
        latest_json_file_path = self.get_latest_json_file(userid)
        with open(latest_json_file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        # 提取指定的字段
        mq_data = {}
        mq_data['task_code'] = data.get('task_code', '')
        mq_data['cost_trcoin'] = data.get('cost_trcoin', '')
        mq_data['script_url'] = data.get('script_url', '')
        mq_data['relatedIds'] = data.get('relatedIds', '')
        mq_data['userId'] = data.get('userId', '')
        mq_data['android_exe_status'] = data.get('android_exe_status', '')
        mq_data['start_time'] = data.get('start_time', '')
        # mq_data['content'] = data.get('content', {})
        return mq_data

    def get_latest_json_file(self, userid):
        """
        根据userid从task_json文件夹中查找指定的userid文件夹，
        再获取最新的json文件，并返回文件路径
        """
        base_path = f"task_json/userid_{userid}"
        latest_json_file_path = ""
        if os.path.exists(base_path):
            json_files = [f for f in os.listdir(base_path) if f.endswith('.json')]
            if json_files:
                latest_json_file_path = os.path.join(base_path, max(json_files, key=os.path.getctime))
        else:
            print(f"用户{userid}的文件夹不存在")
        return latest_json_file_path



