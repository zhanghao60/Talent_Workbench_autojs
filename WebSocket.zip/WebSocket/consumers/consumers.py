import json
from channels.generic.websocket import AsyncWebsocketConsumer
from django.core.cache import cache
from .utils import Utils

# 实例化工具类
utils = Utils()

# 接口类，用于处理WebSocket连接和消息
class Consumers(AsyncWebsocketConsumer):
    # 1.连接建立时调用
    async def connect(self):
        # 获取客户端ID,也就是用户名，例如456456
        self.client_id = self.scope['url_route']['kwargs']['client_id']
        print("=============")
        print("已经连接客户端")
        print(f'客户端ID：{self.client_id}')
        print("=============")
        # 将client_id与channel_name关联存储，用于将前端的http请求转发给指定的客户端
        cache.set(f"ws_{self.client_id}", self.channel_name, 3600)
        await self.accept()

    # 2.服务端接收autojs消息
    async def receive(self, text_data=None):
        data = json.loads(text_data)
        print(f'客户端ID:{self.client_id}发来的消息：{data}')

    # 3. 服务端向autojs发送消息
    async def send_message(self,data):
        # data是字典，用于存储消息内容
        json_data = data
        text_data = json.dumps(json_data)
        await self.send(text_data=text_data)

    # 4. 连接关闭时调用
    async def disconnect(self, close_code):
        # 移除关联
        cache.delete(f"ws_{self.client_id}")

    # http转发给autojs
    async def http_message(self, event): # 函数名要和视图中的type一致
        # event是从视图转发过来的字典，包含'message'字段
        message = event['message']  # message即HTTP请求中的JSON数据
        print(f'http请求发过来的消息：{message}')
        
        # 调用工具类处理消息，提取指定字段
        http_data = utils.process_http_message(message)
        print(f'提取的http_data：{http_data}')
        
        userId = http_data['userId']

        mq_data = utils.process_mq_message(userId)
        print(f'提取的mq_data：{mq_data}')
        
        data = {
            "http_data": http_data,
            "mq_data": mq_data
        }
        
        # 将消息发送给前端WebSocket客户端
        data = {
            'type': 'forwarded',  # 标识这是转发的消息
            'data': data  # 发送处理之后的消息
        }
        await self.send_message(data)


